({
  grand_parent_id: 'grand_parent1',
  parent_contexts: [
    {
      parent_id: 'parent1',
      child_contexts: [
        { child_id: 'parent1-child1' },
        { child_id: 'parent1-child2' }
      ]
    },
    {
      parent_id: 'parent2',
      child_contexts: [
        { child_id: 'parent2-child1' },
        { child_id: 'parent2-child2' }
      ]
    }
  ]
})
