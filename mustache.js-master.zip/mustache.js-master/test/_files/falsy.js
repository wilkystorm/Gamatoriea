({
  "emptyString": "",
  "emptyArray": [],
  "zero": 0,
  "null": null,
  "undefined": undefined,
  "NaN": 0/0
})